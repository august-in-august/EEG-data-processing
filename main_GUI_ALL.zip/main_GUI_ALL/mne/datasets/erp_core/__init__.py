"""ERP-CORE EEG dataset."""

from .erp_core import data_path, get_version
