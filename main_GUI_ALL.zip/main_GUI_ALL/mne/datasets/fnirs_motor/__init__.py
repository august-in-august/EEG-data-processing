"""fNIRS motor dataset."""

from .fnirs_motor import data_path, get_version
