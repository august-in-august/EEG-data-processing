"""HF-SEF dataset."""

from .hf_sef import data_path
