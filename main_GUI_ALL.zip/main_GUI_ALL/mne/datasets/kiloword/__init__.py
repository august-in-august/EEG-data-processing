"""MNE visual_92_categories dataset."""

from .kiloword import data_path, get_version
