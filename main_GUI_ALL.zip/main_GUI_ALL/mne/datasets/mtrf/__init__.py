"""mTRF Dataset."""

from .mtrf import data_path, get_version
