"""Multimodal dataset."""

from .phantom_4dbti import data_path, get_version
