"""Somatosensory dataset."""

from .somato import data_path, get_version
