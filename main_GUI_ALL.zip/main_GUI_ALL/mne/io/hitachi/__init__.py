"""fNIRS module for conversion to FIF."""

# Author: Eric Larson <larson.eric.d@gmail.com>
#
# License: BSD-3-Clause

from .hitachi import read_raw_hitachi
