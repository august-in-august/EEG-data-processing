"""Nihon Kohden module for conversion to FIF."""

# Author: Fede Raimondo <federaimondo@gmail.com>
#
# License: BSD-3-Clause

from .nihon import read_raw_nihon
