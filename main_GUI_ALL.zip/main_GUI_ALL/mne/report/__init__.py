from .report import Report, open_report, _ReportScraper
